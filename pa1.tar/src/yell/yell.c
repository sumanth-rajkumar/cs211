#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main(int argc, char *argv[])
{
    
    if (argc>2 || argc == 1) 
    {
        return 1;
    }
      
    int size = strlen(argv[1]);

    char *s = argv[1];
    int l = strlen(s);

    if(size == 0)
    {
        return 0;
    }
    else
    {   
        for(int i = 0; i<l; i++)
        {
            printf("%c", toupper(s[i]));
        }
        printf("%c%c%c", '!', '!', '\n');
    }
    return 0;
}