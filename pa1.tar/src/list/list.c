#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>


struct Node
{
    int data;
    struct Node *next;
};

int has(struct Node *h, int n)
{
    struct Node *c = h;

    while(c != NULL)
    {
        if(c->data == n)
        return 1;
        c = c->next;
    }
    return 0;

}
struct Node* insert(struct Node *h, int data)
{

    if(has(h,data) == 1)
    {   
        return h;
    }
    struct Node *n = (struct Node*)malloc(sizeof(struct Node));
    if(n != NULL)
    {
        n->data = data;
        n->next = NULL;
        if(h == NULL)
        {
            h = n;
        }
        else
        {
            struct Node *c = h;
            struct Node *t = NULL;
            while(c != NULL)
            {
                if(c->data > n->data)
                {
                    if(t == NULL)
                    {
                        n->next = h;
                        h = n;
                    }
                    else
                    {
                        n->next = c;
                        t->next = n;

                    }
                    return h;
                }
                t = c;
                c = c->next;
            }
            t->next = n; 
        }

    }
    return h;
}
struct Node* delete(struct Node* h, int data)
{
    
    if(h != NULL)
    {
        if(h->data == data)
        {
            struct Node *t = h;
            h = h->next;
            free(t); 
        }
        else
        {
            struct Node *c = h;
            struct Node *t = NULL;

            while(c != NULL)
            {
                if(c->data == data)
                {
                    t->next = c->next;
                    free(c);
                    return h;
                }
                t = c;
                c = c->next;
            }

        }    
    }   
    return h;
}
int length(struct Node* h)
{
    int cnt = 0;
    struct Node *c = h;
   
    while(c != NULL)
    {
        cnt++;
        c = c->next;
    }
    return cnt;

}
void print(struct Node *h)
{
    struct Node *c = h;
   
    while(c != NULL)
    {
        if(c->next == NULL)
        {
	        printf("%d", c->data);
        }
        else
        {
	       printf("%d ", c->data);
	    }
        c = c->next;
    }

}
void freeMem(struct Node *h)
{
    struct Node *c;
    while(h != NULL)
    {
        c = h;
        h = h->next;
        free(c);
    }
}
int main(void) 
{
    struct Node *h = NULL; 
    int data;
    char command;
    
    do
    {
        fflush(stdout);
        
        int a = scanf(" %c %d", &command, &data);
        
        if((tolower(command) != 'i') && (tolower(command) != 'd'))
        {
            break;
        }
        if(a == EOF)
        {
           break;
        }
        if(tolower(command) == 'i')
        { 
            h = insert(h,data);
        }
        else
        {
            h = delete(h,data);
        } 
        int size = length(h);
        if(size==0)
        {
           printf("%d :", size);
        } 
        else 
        {
           printf("%d : ", size);
        }
        print(h); 
        printf("\n");
    }
    while((tolower(command) == 'd') || (tolower(command) == 'i'));
    freeMem(h); 
    return EXIT_SUCCESS;

}


