#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

struct node
{
    struct node *r;
    struct node *l;
    int val;
};

struct node *insert(struct node *n, int val)
{
  if(n == NULL)
  {
    struct node *new = malloc(sizeof(struct node));
    new->val = val;
    new->r = NULL;
    new->l = NULL;
    printf("inserted\n");
    return new;
  }
  if(n->val == val)
  {
    printf("not inserted\n");
    return n;
  }
  else if (n->val < val)
  {
    n->r = insert(n->r, val);
  }
  else if (n->val > val)
  {
    n->l = insert(n->l, val);
  }
  return n;
}
int search(struct node *n, int val)
{
  if(n == NULL)
  {
    printf("absent\n");
    return 0;
  }
  else if(n->val < val)
  {
    return search(n->r, val);
  }
  else if (n->val > val)
  {
    return search(n->l, val);
  }
  else 
  {
    printf("present\n");
    return 1;
  }
 
}
void print(struct node *n)
{
  if (n == NULL)
  {
      return;
  }
  printf("(");
  print(n->l);
  printf("%d", n->val);
  print(n->r);
  printf(")");;

}
struct node *getIS(struct node  *n)
{
    struct node* c = n;
    while (c->l && c != NULL)
    {
      c = c->l;
    }
    return c;
}
struct node *delete(struct node *n, int val, bool p)
{
    if (n == NULL)
    {
      printf("absent\n");
      return n;
    }
    if (n->val > val)
    {
        n->l = delete(n->l, val, p);
    }
    else if (n->val < val)
    {
        n->r = delete(n->r, val, p);
    }
    else
    {
        if(p)
        {
        printf("deleted\n");
        }
        if (n->l == NULL)
        {
            struct node *t = n->r;
            free(n);
            return t;
        }
        else if (n->r == NULL)
        {
            struct node *t = n->l;
            free(n);
            return t;
        }
        struct node *t = getIS(n->r);
        n->val = t->val;
        n->r = delete(n->r, t->val, false);
    }
    return n;
}
void freeN(struct node *n)
{
  if(n->l!=NULL)
  {
    freeN(n->l);
  }
  if(n->r!=NULL)
  {
    freeN(n->r);
  }
  free(n);
}

struct node *r = NULL;

int main(int argc, char *argv[])
{
  char file[3000];
  while (fgets(file, 3000, stdin))
  {
      char command = file[0];
      file[0]=' ';
      int uI = atoi(file);
      if(command == 's')
      {
        search(r, uI);
      }
      else if(command =='i')
      {
        r = insert(r, uI);
      }
      else if(command == 'p')
      {
        print(r);
        printf("\n");
      }
      else if(command == 'd')
      {
        r = delete(r, uI, true);
      }
  }
  freeN(r);
}