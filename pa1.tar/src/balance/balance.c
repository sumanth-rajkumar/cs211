#include<stdio.h>
#include<string.h>
#include<stdlib.h>

char pop(char stack[], int *t) 
{
    if (*t == 0) 
    {
        return '\0';
    }
    *t = *t - 1;
    char pC = stack[*t];
    return pC;
}
void push(char stack[], char c, int *t) 
{
    stack[*t] = c;
    *t = *t + 1;
}
char peekStack(char stack[], int *t) 
{
    return stack[*t - 1];
}
char getCounter(char bT) 
{
 
    if (bT == '(')
    { 
        return ')';
    }
    if (bT == '{')
    {
        return '}';
    }
    if (bT == '[') 
    {
        return ']';
    }
    exit(0);
}
int checkCounter(char gE, char pE) 
{
    if ((gE == '}' && pE == '{') || (gE == ')' && pE == '(') || (gE == ']' && pE == '['))
    {
        return 1;
    }
    return 0;
}
int checkBalance(char *s) 
{
   char stack [100];
   int t = 0;
   int *tPtr = &t;
   int i = 0;

   while(s[i] != '\0') 
   {
        char gE = s[i];
        if (gE == '(' || gE == '{' || gE == '[')
        {    
            push(stack, gE, tPtr);
        }
        else if (gE == ')' || gE == '}' || gE== ']') 
        {
            if(t == 0)
            {
                printf("%d: %c", i, gE);
                printf("\n");
                return(1);
            } 

            char pC = peekStack(stack, tPtr);
            if (!checkCounter(gE, pC)) 
            {
                printf("%d: %c", i, gE);
                return EXIT_FAILURE;
            }
            pop(stack, tPtr);
        }
        i++;
    }
    if (t == 0) 
    {
        return EXIT_SUCCESS;
    }
    printf("open: ");

    while (t != 0) 
    {
        char tB = pop(stack, tPtr);
        printf("%c", getCounter(tB));
    }
    return EXIT_FAILURE;
}

int main(int argc, char **argv) 
{
    char *s = argv[1];
    int r = checkBalance(s);
    return r;
}