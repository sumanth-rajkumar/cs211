#include<stdio.h>
#include<stdlib.h>



int **mallocSquareMatrix(int size) 
{
    int **result = (int**) malloc(sizeof(int *) *size);
    for (int i = 0; i < size; i++)
    {
        result[i] = (int *)malloc(sizeof(int)*size);

    }
    return result;
}
int **clone(int **A, int size)
{
    int** B = mallocSquareMatrix(size);
    for(int i=0; i<size; i++)
    {
        for(int j=0; j<size; j++)
        {
            B[i][j]=A[i][j];
            
        }
       
    }
    return B;
}
void printMatrix(int size,int **matrix)
{
  for(int i=0; i<size; i++)
  {
    for(int j=0; j<size; j++)
    {
      if(j==size-1)
      {
        printf("%d", matrix[i][j]);
      }
      else
      {
        printf("%d ", matrix[i][j]);
      }
    }
    printf("\n");
  }
}
void freeSquareMatrix(int**matrix, int size) {
    
    for (int i = 0; i < size; i++)
    {
        free(matrix[i]); 

    }
    free(matrix);
}
int** multiply(int size, int **m1, int **m2, int** result)
{
   
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            result[i][j] = 0;
            for (int k = 0; k < size; k++)
            {
                result[i][j] += m1[i][k]*m2[k][j];
            }

        }
    }
    return result;
}

int **matrixPower(int **A, int size, int n)
{

    if(n == 0)
    {
        for(int i = 0 ; i < size ; i++ )
        {
            for (int j = 0 ; j < size ; j++ )
            {
                if(i == j)
                { 
                    A[i][j] = 1;
                }
                else
                {
                    A[i][j] = 0;
                }                       

            }

        }
        return A;
    }
    else if(n == 1)
    {
        return A;
    }
                    
    int** PR = clone(A, size);
    int** R = mallocSquareMatrix(size);
    
    for(int c = 0; c < n-1; c++)
    {
        multiply(size, A, PR, R);
        int **T = PR;
        PR = R;
        R = T;
    }
    freeSquareMatrix(R, size);
    return PR; 

}

int main(int argc, char *argv[])
{
    
    if(argc!=2)
    {
    printf("Enter a single argument.\n");
    return 0;
    }
    
    FILE *file;
    file = fopen(argv[1], "r");
    
    if(file == NULL)
    {
        printf("Error\n");
        return 1;
    }
    
    int size;
    fscanf(file, "%d ", &size);

    int** A = mallocSquareMatrix(size);

    for(int i = 0; i <size;i++)
    {
      for(int j =0; j<size; j++)
      {
        int v;
        fscanf(file, "%d ", &v);
        A[i][j]=v;
      }
    }
    int power;
    fscanf(file, "%d ", &power);
   

    int **R = matrixPower(A, size, power);
   
    printMatrix(size, R);
    freeSquareMatrix(A, size);
    if(power>1)
    {
        freeSquareMatrix(R, size);
    }
    return 0;

}