#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(int argc, char* argv[])
{

    char *uI = argv[1];
    int s = strlen(uI);
    if (s < 1) 
    {
        return 0;
    } 

    char num[10] = {'0','1','2','3','4','5','6','7','8','9'};
    
    for(int i=0; i<10; i++)
    {
        for(int j=0; j<s; j++)
        {
            if(num[i] == uI[j])
            {
                printf("error\n");
                return 0;
            }
        }
    }
  
    char* Cs = (char *)malloc((sizeof(char) + sizeof(int)) *s + 1);
    int cnt = 1;
    int t = 0;
    char p = uI[0];

    for (int i=1; i<s; i++)
    {
        if(uI[i] == p)
        {
            cnt++;
        }   
        else 
        {
            t += sprintf(Cs+t, "%c%d", p, cnt); 
            cnt = 1;
        } 
        p = uI[i];
    }
    t += sprintf(Cs+t, "%c%d\n", p, cnt);
    Cs[t-1] = '\0';

    if (strlen(Cs) <= s) 
    {
        printf("%s\n", Cs);
    } 
    else 
    {
        printf("%s\n", uI);
    }
    free(Cs);
    return 0;
}